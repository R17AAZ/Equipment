from django.contrib import admin
from .models import User, Equipment, Reservation

admin.site.register(User)
admin.site.register(Equipment)
admin.site.register(Reservation)