from django.contrib.auth import logout, login, authenticate
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.forms import AuthenticationForm
from django.urls import reverse_lazy
from .forms import UserRegistrationForm, ReservationForm, EquipmentForm
from .models import Equipment, Reservation

def home(request):
    return render(request, 'inventory/home.html')

def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=password)
            login(request, user)
            return redirect('equipment_list')
    else:
        form = UserRegistrationForm()
    return render(request, 'inventory/register.html', {'form': form})

def user_login(request):
    error_message = None
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('equipment_list')
            else:
                error_message = 'Invalid username or password.'
        else:
            error_message = 'Invalid username or password.'
    else:
        form = AuthenticationForm()
    return render(request, 'inventory/login.html', {'form': form, 'error_message': error_message})

def user_logout(request):
    logout(request)
    return redirect(reverse_lazy('login'))

@login_required
def equipment_list(request):
    equipments = Equipment.objects.all()
    reservations = Reservation.objects.filter(user=request.user).values_list('equipment_id', flat=True)
    return render(request, 'inventory/equipment_list.html', {
        'equipments': equipments,
        'reservations': reservations
    })

@login_required
def reserve_equipment(request, equipment_id):
    equipment = Equipment.objects.get(id=equipment_id)
    if request.method == 'POST':
        form = ReservationForm(request.POST)
        if form.is_valid():
            reservation = form.save(commit=False)
            reservation.user = request.user
            reservation.save()
            return redirect('my_reservations')
    else:
        form = ReservationForm(initial={'equipment': equipment})
    return render(request, 'inventory/reserve_equipment.html', {'form': form, 'equipment': equipment})

@login_required
def my_reservations(request):
    reservations = Reservation.objects.filter(user=request.user)
    return render(request, 'inventory/my_reservations.html', {'reservations': reservations})

@login_required
def admin_reservations(request):
    reservations = Reservation.objects.all()
    return render(request, 'inventory/admin_reservations.html', {'reservations': reservations})






@login_required
def add_equipment(request):
    if request.method == 'POST':
        form = EquipmentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('equipment_list')  # Redirect to equipment list after adding
    else:
        form = EquipmentForm()
    return render(request, 'inventory/add_equipment.html', {'form': form})

@login_required
def edit_equipment(request, equipment_id):
    equipment = get_object_or_404(Equipment, id=equipment_id)
    if request.method == 'POST':
        form = EquipmentForm(request.POST, instance=equipment)
        if form.is_valid():
            form.save()
            return redirect('equipment_list')  # Redirect to equipment list after editing
    else:
        form = EquipmentForm(instance=equipment)
    return render(request, 'inventory/edit_equipment.html', {'form': form, 'equipment': equipment})

@login_required
def equipment_details(request, equipment_id):
    equipment = get_object_or_404(Equipment, id=equipment_id)
    return render(request, 'inventory/equipment_details.html', {'equipment': equipment})
