from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('register/', views.register, name='register'),
    path('equipment/', views.equipment_list, name='equipment_list'),
    path('reserve/<int:equipment_id>/', views.reserve_equipment, name='reserve_equipment'),
    path('my_reservations/', views.my_reservations, name='my_reservations'),
    path('admin_reservations/', views.admin_reservations, name='admin_reservations'),
    path('accounts/login/', views.user_login, name='login'),
    path('logout/', views.user_logout, name='logout'),

    path('add_equipment/', views.add_equipment, name='add_equipment'),
    path('edit_equipment/<int:equipment_id>/', views.edit_equipment, name='edit_equipment'),
    path('equipment_details/<int:equipment_id>/', views.equipment_details, name='equipment_details'),
]
