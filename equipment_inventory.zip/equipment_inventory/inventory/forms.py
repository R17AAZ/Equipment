from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import User, Reservation, Equipment

class UserRegistrationForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'password1', 'password2']

class ReservationForm(forms.ModelForm):
    class Meta:
        model = Reservation
        fields = ['equipment']
        # widgets = {
        #     'equipment': forms.HiddenInput()
        # }
        widgets = {
            'equipment': forms.Select(attrs={'class': 'form-control'})
        }


class EquipmentForm(forms.ModelForm):
    class Meta:
        model = Equipment
        fields = '__all__'